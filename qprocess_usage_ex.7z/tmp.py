text_file = open("output", "w")
text_file.write("hello world!!")
text_file.close()