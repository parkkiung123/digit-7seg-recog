#include "mainwindow.h"
#include <QApplication>
#include <QProcess>
#include <QFile>

int main(int argc, char *argv[])
{
    QProcess* process = new QProcess();
    QString program = "./tmp.bat";
    process->start(program);
    process->waitForFinished();

    QFile f("./output");
    if (f.open(QFile::ReadOnly | QFile::Text))
    {
        QTextStream in(&f);
        qDebug() << in.readAll();
        f.close();
    }

    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    return a.exec();
}