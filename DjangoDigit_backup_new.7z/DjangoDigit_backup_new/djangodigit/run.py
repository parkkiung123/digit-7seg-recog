import subprocess
import time
import psutil, os

def kill_proc_tree(pid, including_parent=True):
    parent = psutil.Process(pid)
    children = parent.children(recursive=True)
    for child in children:
        child.kill()
    gone, still_alive = psutil.wait_procs(children, timeout=5)
    if gone and including_parent:
        parent.kill()
        parent.wait(5)

try:
    cmd1 = "python ./manage.py runserver"
    cmd2 = "python ./frame_based_server.py"
    p1 = subprocess.Popen(cmd1, shell=True)
    p2 = subprocess.Popen(cmd2, shell=True)
    while True:
        time.sleep(1)
except:
    me = os.getpid()
    kill_proc_tree(me)