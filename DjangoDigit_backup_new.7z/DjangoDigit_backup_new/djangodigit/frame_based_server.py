import json
import time
import cv2
import numpy as np
from twisted.internet import reactor
from twisted.internet.ssl import DefaultOpenSSLContextFactory
from twisted.python import log
from PIL import Image, ImageOps
from io import BytesIO
import urllib.parse
import base64
import os, sys
sys.path.append(os.getcwd())
from digits_recognizer import recog_main
from datetime import datetime

from autobahn.twisted.websocket import WebSocketServerFactory, \
    WebSocketServerProtocol, \
    listenWS

class RecogServerProtocol(WebSocketServerProtocol):

    def onConnect(self, request):
        print("Client connecting: {0}".format(request.peer))
        self.training = True

    def onOpen(self):
        print("WebSocket connection open.")

    def onMessage(self, payload, isBinary):
        raw = payload.decode('utf8')
        msg = json.loads(raw)
        print("Received {} message of length {}.".format(
            msg['type'], len(raw)))
        if msg['type'] == "NULL":
            self.sendMessage(json.dumps({"type": "NULL"}).encode("utf8"))
        elif msg['type'] == "RECOG_FROM_SETTING":
            self.processFrame(msg)
        elif msg['type'] == "PHOTO":
            self.saveFrame(msg['dataURL'])
        else:
            print("Warning: Unknown message type: {}".format(msg['type']))

    def onClose(self, wasClean, code, reason):
        print("WebSocket connection closed: {0}".format(reason))

    def base64toCVIMG(self, dataURL):
        head = "data:image/jpeg;base64,"
        assert (dataURL.startswith(head))
        imgdata = base64.b64decode(dataURL[len(head):])
        nparr = np.fromstring(imgdata, np.uint8)
        return cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    def processFrame(self, msg):
        # フレーム取得
        image = self.base64toCVIMG(msg["dataURL"])

        # 7-segmentsの数字認識
        out_list = list()
        for coord in json.loads(msg['coord']):
            out_list.append(self.recogDigits(image, coord, msg['invert']))

        # メッセージ送信
        msg = {
            "type": "RECOG_FROM_SETTING",
            "result": out_list,
        }
        self.sendMessage(json.dumps(msg).encode("utf8"))

    def base64toPIL(self, dataURL):
        head = "data:image/jpeg;base64,"
        assert (dataURL.startswith(head))
        imgdata = base64.b64decode(dataURL[len(head):])
        imgF = BytesIO()
        imgF.write(imgdata)
        imgF.seek(0)
        return Image.open(imgF)

    def saveFrame(self, dataURL):
        img = self.base64toPIL(dataURL)
        filename = datetime.now().strftime("%Y%m%d_%H%M%S") + ".jpg"
        img.save("./mainApp/static/upload/photo/" + filename)

        msg = {
            "type": "SAVED",
            "file_name" : filename + ".jpg",
        }
        self.sendMessage(json.dumps(msg).encode("utf8"))

    # フレームと範囲から数字を認識
    def recogDigits(self, image, coord, invert):
        x, y, w, h = [int(x) for x in coord.split(',')]
        return {"digits": recog_main(image[y:h, x:w], invert), "coord": {"x": x, "y": y}}


if __name__ == '__main__':
    log.startLogging(sys.stdout)
    factory = WebSocketServerFactory("wss://localhost:9000")
    factory.protocol = RecogServerProtocol

    enableCompression = False
    if enableCompression:
        from autobahn.websocket.compress import PerMessageDeflateOffer, \
            PerMessageDeflateOfferAccept

        def accept(offers):
            for offer in offers:
                if isinstance(offer, PerMessageDeflateOffer):
                    return PerMessageDeflateOfferAccept(offer)

        factory.setProtocolOptions(perMessageCompressionAccept=accept)

    tls_crt = os.path.join('/', 'ssl', 'server.crt')
    tls_key = os.path.join('/', 'ssl', 'server.key')
    ctx_factory = DefaultOpenSSLContextFactory(tls_key, tls_crt)

    listenWS(factory, contextFactory=ctx_factory)
    reactor.run()
