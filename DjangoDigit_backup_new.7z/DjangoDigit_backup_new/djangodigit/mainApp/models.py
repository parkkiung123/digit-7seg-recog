from django.db import models

# Setting Model
class Setting(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50, null=False)
    coord = models.CharField(max_length=25, null=False)
    result = models.CharField(max_length=100, null=True)