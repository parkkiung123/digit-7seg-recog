navigator.getUserMedia = navigator.getUserMedia ||
    navigator.webkitGetUserMedia ||
    (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) ?
        function(c, os, oe) {
            navigator.mediaDevices.getUserMedia(c).then(os,oe);
        } : null ||
    navigator.msGetUserMedia;

window.URL = window.URL ||
    window.webkitURL ||
    window.msURL ||
    window.mozURL;

window.requestAnimFrame = (function() {
    return window.requestAnimationFrame ||
        window.webkitRequestAnimationFrame ||
        window.mozRequestAnimationFrame ||
        window.oRequestAnimationFrame ||
        window.msRequestAnimationFrame ||
        function(/* function FrameRequestCallback */ callback, /* DOMElement Element */ element) {
            return window.setTimeout(callback, 1000/60);
        };
})();

var global = "None"

function sendFrameLoop() {

    if (global == "None") {
        return;
    }

    if (socket == null || socket.readyState != socket.OPEN ||
        !vidReady || numNulls != defaultNumNulls) {
        return;
    }
    if (tok > 0) {

        if (global.type == "RECOG_FROM_SETTING") {
            var dataURL = preview.toDataURL('image/jpeg', 0.2)
            var msg = {
                'type': global.type,
                'dataURL': dataURL,
                'coord': global.coord,
                'invert': global.invert
            };
            socket.send(JSON.stringify(msg));
            tok--;
        } else {
            preview.width = vid.width;
            preview.height = vid.height;
            ctx.drawImage(vid, 0, 0, vid.width, vid.height);
        }

    }
    setTimeout(function() {requestAnimFrame(sendFrameLoop)}, 33);

}

function createSocket(address, name, jsonInput) {
    socket = new WebSocket(address);
    socketName = name;
    socket.binaryType = "arraybuffer";
    socket.onopen = function() {
        $("#serverStatus").html("Connected to " + name);
        sentTimes = [];
        receivedTimes = [];
        tok = defaultTok;
        numNulls = 0
        socket.send(JSON.stringify({'type': 'NULL'}));
        sentTimes.push(new Date());
    }
    socket.onmessage = function(e) {
        console.log(e);
        j = JSON.parse(e.data)
        if (j.type == "NULL") {
            receivedTimes.push(new Date());
            numNulls++;
            if (numNulls == defaultNumNulls) {
                global = jsonInput
                sendFrameLoop();
            } else {
                socket.send(JSON.stringify({'type': 'NULL'}));
                sentTimes.push(new Date());
            }
        } else if (j.type == "RECOG_FROM_SETTING") {
            tok++;
            preview.width = vid.width;
            preview.height = vid.height;
            ctx.drawImage(vid, 0, 0, vid.width, vid.height);
            $.each(j.result, function() {
               ctx.font = "14px Arial";
               ctx.fillStyle = "red";
               ctx.fillText(this.digits,
                            parseInt(this.coord.x) + 3,
                            parseInt(this.coord.y) + 15)
            })
        } else if (j.type == "SAVED") {
            alert("写真が取れました : " + j.file_name)
        }
    }
    socket.onerror = function(e) {
        console.log("Error creating WebSocket connection to " + address);
        console.log(e);
    }
    socket.onclose = function(e) {
        if (e.target == socket) {
            $("#serverStatus").html("Disconnected.");
        }
    }
}

var vid = document.getElementById('videoElement'), vidReady = false;
var defaultTok = 1, defaultNumNulls = 20;
var tok = defaultTok;
var numNulls, sentTimes, receivedTimes;
var socket, socketName;

function umSuccess(stream) {
    if (vid.mozCaptureStream) {
        vid.mozSrcObject = stream;
    } else {
        vid.src = (window.URL && window.URL.createObjectURL(stream)) ||
            stream;
    }
    vid.play();
    vidReady = true;
    sendFrameLoop();
}

if (navigator.getUserMedia) {
    var videoSelector = {video : true};
    navigator.getUserMedia(videoSelector, umSuccess, function() {
        alert("Error fetching video from webcam");
    });
    } else {
        alert("No webcam detected.");
}

createSocket("wss://" + window.location.hostname + ":9000", "Local", {"type": "INIT"});