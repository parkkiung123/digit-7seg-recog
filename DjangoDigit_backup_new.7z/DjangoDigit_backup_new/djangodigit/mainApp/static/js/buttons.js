// カメラ撮影開始
$("#playvideo").click(function() {
    createSocket("wss://" + window.location.hostname + ":9000", "Local", {'type': 'INIT'});
});

// カメラ撮影中止
$("#stopvideo").click(function() {
    socket.close();
})

// 写真撮り
$("#takepicture").click(function() {

    if (socket == null || socket.readyState != socket.OPEN) {
        alert("ソケット通信が切れています")
        return;
    }

    var dataURL = preview.toDataURL('image/png')
    var msg = {
        'type': 'PHOTO',
        'dataURL': dataURL
    };
    socket.send(JSON.stringify(msg));

})

// リアルタイム認識
$("#recogRealBtn").click(function() {
    var name = $("#settingname").val()
    var coord = $("#readrange").val()
    var invert = $("#invert:checked").val()
    if (typeof(invert) === "undefined") {
        invert = "0"
    }
    if (name.length === 0 || coord.length === 0) {
        alert("設定の名前と座標を入力してください")
    } else {
        if (socket == null || socket.readyState != socket.OPEN) {
            alert("ソケット通信が切れています")
            return;
        }
        socket.close()
        jsonMsg = {'type': 'RECOG_FROM_SETTING', 'coord': JSON.stringify([coord]), 'invert': invert}
        createSocket("wss://" + window.location.hostname + ":9000", "Local", jsonMsg);
    }
})

// リアルタイム認識(マルチ設定から)
$("#multiRecog").click(function() {
    var invertMulti = $("#invertMulti:checked").val()
    if (typeof(invertMulti) === "undefined") {
        invertMulti = "0"
    }
    var coordArr = new Array()
    $.each($("input[id^='chkMultiUsage_']:checked"), function() {
        coordArr.push($("#coord_" + $(this).attr("id").split("_")[1]).html())
    })
    if (coordArr.length === 0) {
        alert("チェックボックスからひとつ以上の設定を選択してください")
        return
    }
    if (socket == null || socket.readyState != socket.OPEN) {
        alert("ソケット通信が切れています")
        return;
    }
    socket.close()
    jsonMsg = {'type': 'RECOG_FROM_SETTING', 'coord': JSON.stringify(coordArr), 'invert': invertMulti}
    createSocket("wss://" + window.location.hostname + ":9000", "Local", jsonMsg);
})

// 入力クリア
$("#clearinput").click(function() {
    $("#settingname").val("")
    $("#readrange").val("")
})

// 設定登録
$("#savesetting").click(function() {
    var name = $("#settingname").val()
    var coord = $("#readrange").val()
    if (name.length === 0 || coord.length === 0) {
        alert("設定の名前と座標を入力してください")
    } else {
        $.get("insertSetting", {"name": name, "coord": coord}).done(function(data) {
            $("#settings_table_tbody").html(data)
            alert("設定の登録に成功しました")
        })
    }
})

// spanボタンで設定をひとつ削除
$("#settings_table_tbody").on('click', "span[id^='spanDel_']", function() {
    var id = $(this).attr("id")
    var pk = id.split("_")[1]
    $.get("deleteSetting", {"pk": pk}).done(function(data) {
        $("#settings_table_tbody").html(data)
        newRange = $("#canvaswrapper").find("div")
        $.each($(newRange), function() {
            if ($(this).attr("id").split("_")[1] == pk) {
                $(this).remove()
                return;
            }
        })
        alert("設定の削除に成功しました")
    })
})

// 設定のRangeを表示
$("#settings_table_tbody").on('click', "input[id^='chkShow_']", function() {
    var pk = $(this).attr("id").split("_")[1]
    var newRangeId = "range_" + pk
    if ($(this).prop("checked")) {
        $.get("getSetting", {"pk": pk}).done(function(data) {
            if (data.result === "Success") {
                $("#settingname").val(data.target.name)
                $("#readrange").val(data.target.coord)
                var newRange = "<div id=" + newRangeId + "></div>"
                newRange = $("#canvaswrapper").append(newRange).find("div")
                newRange = newRange[newRange.length -1]
                newRange.base = {x:0, y:0};
                range_sel = data.target.coord.split(",")
				newRange.style.top = range_sel[1] + 'px';
				newRange.style.left = range_sel[0] + 'px';
				newRange.style.width = range_sel[2] - range_sel[0] + 'px';
				newRange.style.height = range_sel[3] - range_sel[1] + 'px';
				newRange.style.display = 'block';
				$(newRange).addClass("rangeStyle")
            } else if (data.result === "Fail") {
                alert("設定の取得に失敗しました")
            }
        })
    } else {
        newRange = $("#canvaswrapper").find("div")
        $.each($(newRange), function() {
            if ($(this).attr("id").split("_")[1] == pk) {
                $(this).remove()
                return;
            }
        })
    }
})

// 選択した設定を削除
$("#delChecked").click(function() {
    var pkArr = new Array()
    $.each($("input[id^='chkMultiUsage_']:checked"), function() {
        pkArr.push($(this).attr("id").split("_")[1])
    })
    if (pkArr.length === 0) {
        alert("チェックボックスからひとつ以上の設定を選択してください")
        return
    }
    $.get("deleteSetting", {"pkArr": JSON.stringify(pkArr)}).done(function(data) {
        $("#settings_table_tbody").html(data)
        $.each(pkArr, function() {
            var pk = this
            newRange = $("#canvaswrapper").find("div")
            if ($(newRange).length) {
                $.each($(newRange), function() {
                    if ($(this).attr("id").split("_")[1] == pk) {
                        $(this).remove()
                        return;
                    }
                })
            }
        })
        alert("設定の削除に成功しました")
    })
})

// すべての設定を削除
$("#delAll").click(function() {
    $.get("deleteSetting", {"all": 1}).done(function(data) {
        $("#settings_table_tbody").html(data)
        newRange = $("#canvaswrapper").find("div")
        if ($(newRange).length) {
            $.each($(newRange), function() {
                if ($(this).attr("id").search("_") > 0) {
                    $(this).remove()
                }
            })
        }
        alert("設定の削除に成功しました")
    })
})