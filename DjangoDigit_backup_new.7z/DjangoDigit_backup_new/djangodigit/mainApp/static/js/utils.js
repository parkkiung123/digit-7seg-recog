// キャンバス
var preview = document.getElementById('preview');
preview.rangestart = false;
if (!preview || !preview.getContext) {
    alert('あれれ');
}

// context
var ctx = preview.getContext('2d');

// ajax javascript version
function ajax(param) {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (this.readyState == 4) {
            if (this.status == 200) {
                param.success(this.response.trim());
            } else {
                param.failed(this);
            }
        }
    }
    if (param.formData) {
        xhr.open('POST', param.action, true);
        xhr.send(param.formData);
    } else {
        xhr.open('GET', param.action, true);
        xhr.send(null);
    }
}

// マウスによる範囲指定 (start)
// range : マウスにより設定される基本範囲
var range = document.getElementById('range');
range.base = {x:0, y:0};

var rangetext = document.getElementById('rangetext');
function setRangeText() {
    var pr = preview.getBoundingClientRect();
    var rr = range.getBoundingClientRect();
    rangetext.value = Math.trunc(rr.x - pr.x) + ',' + Math.trunc(rr.y - pr.y) + ',' + Math.trunc(rr.x + rr.width - pr.x) + ',' + Math.trunc(rr.y + rr.height - pr.y);
}

var copyrange = document.getElementById('copyrange');
copyrange.addEventListener('click', function(){
    document.paramform.readrange.value = rangetext.value;
});

var mouseposition = document.getElementById('mouseposition');
function mouseDownProcess(e) {
    range.base.x = e.pageX;
    range.base.y = e.pageY;
    range.style.top = e.offsetY + 'px';
    range.style.left = e.offsetX + 'px';
    range.style.width = '0px';
    range.style.height = '0px';
    range.style.display = 'block';
    preview.rangestart = true;
    preview.addEventListener('mouseup', mouseUpProcess, false);
    preview.addEventListener('mousemove', mouseMoveProcess, false);
    range.addEventListener('mouseup', mouseUpProcess, false);
    range.addEventListener('mousemove', mouseMoveProcess, false);
    mouseposition.textContent = Math.trunc(range.x) + ',' + Math.trunc(range.y);
}

function mouseDownProcessForRange(e) {
    range.base.x = e.pageX;
    range.base.y = e.pageY;
    range.style.top = parseInt(range.style.top) + e.offsetY + 'px';
    range.style.left = parseInt(range.style.left) + e.offsetX + 'px';
    range.style.width = '0px';
    range.style.height = '0px';
    range.style.display = 'block';
    preview.rangestart = true;
    preview.addEventListener('mouseup', mouseUpProcess, false);
    preview.addEventListener('mousemove', mouseMoveProcess, false);
    range.addEventListener('mouseup', mouseUpProcess, false);
    range.addEventListener('mousemove', mouseMoveProcess, false);
    mouseposition.textContent = range.x + ',' + range.y;
}

function mouseUpProcess(e) {
    preview.rangestart = false;
    preview.removeEventListener('mouseup', mouseUpProcess, false);
    preview.removeEventListener('mousemove', mouseMoveProcess, false);
    range.addEventListener('mouseup', mouseUpProcess, false);
    range.addEventListener('mousemove', mouseMoveProcess, false);
}

function mouseMoveProcess(e) {
    if (preview.rangestart) {
        mouseposition.textContent = 'Point: x:' + e.pageX + ', y:' + e.pageY;
        var x = e.pageX - range.base.x;
        var y = e.pageY - range.base.y;
        range.style.width = x + 'px';
        range.style.height = y + 'px';
        setRangeText();
    }
}

preview.addEventListener('mousedown', mouseDownProcess, false);
range.addEventListener('mousedown', mouseDownProcessForRange, false);
/// マウスによる範囲指定 (end)