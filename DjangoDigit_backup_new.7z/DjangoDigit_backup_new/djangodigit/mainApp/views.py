from django.views import generic
from django.http import HttpResponse
from django.template.loader import render_to_string
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from .models import Setting
import json

# Index View
class index(generic.ListView):
    template_name = 'index.html'
    model = Setting

# REST : GET (get setting)
@csrf_exempt
@require_http_methods(["GET"])
def getSetting(req):
    id = req.GET['pk']
    sobj = Setting.objects
    r = sobj.get(pk=id)
    if r:
        return HttpResponse(json.dumps({"result": "Success",
                                         "target": {"pk": r.id, "name": r.name, "coord": r.coord}}),
                            content_type="application/json")
    else:
        return HttpResponse(json.dumps({"result": "Fail"}), content_type="application/json")

# REST : GET (insert setting)
@csrf_exempt
@require_http_methods(["GET"])
def insertSetting(req):
    name = req.GET['name']
    coord = req.GET['coord']
    sobj = Setting.objects
    sobj.create(name=name, coord=coord)
    html = render_to_string('settings_table_tbody.html', {'object_list': sobj.all()})
    return HttpResponse(html)

# REST : GET (delete setting)
@csrf_exempt
@require_http_methods(["GET"])
def deleteSetting(req):
    sobj = Setting.objects
    # delete all settings
    if req.GET.get('all', False):
        sobj.all().delete()
    # delete multi settings
    elif req.GET.get('pkArr', False):
        objs = json.loads(req.GET['pkArr'])
        for id in objs:
            sobj.filter(pk=id).delete()
    # delete a setting
    else:
        id = req.GET['pk']
        sobj.filter(pk=id).delete()
    html = render_to_string('settings_table_tbody.html', {'object_list': sobj.all()})
    return HttpResponse(html)