from django.urls import path
from . import views

urlpatterns = [
    path('', views.index.as_view()),
    path('getSetting', views.getSetting),
    path('insertSetting', views.insertSetting),
    path('deleteSetting', views.deleteSetting),
]