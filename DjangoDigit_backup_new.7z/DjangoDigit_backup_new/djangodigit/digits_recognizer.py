# coding:utf-8
import cv2
from imutils import contours
from imutils.perspective import four_point_transform
import imutils
import numpy as np
from numpy import linalg as LA

# 切り取った数字が斜めになっているのを直す透視変換
def perspective_tf(thresh):
    contours = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[1]
    cnt = contours[0]
    # 画像から輪郭をepsilon 0.1の丸さ許容で囲むポリゴンの輪郭を取得
    alpha = 0.1
    epsilon = alpha * cv2.arcLength(cnt, True)
    approx = cv2.approxPolyDP(cnt, epsilon, True)
    approx_re = np.zeros((approx.shape[0], approx.shape[2]), dtype="float32")
    for i in range(0, approx_re.shape[0]):
        approx_re[i, :] = approx[i][0]
    # ポリゴンから平行四角形の形を取得
    rect = np.zeros((4, 2), dtype="float32")
    s = approx_re.sum(axis=1)
    rect[0] = approx_re[np.argmin(s)]
    rect[2] = approx_re[np.argmax(s)]
    rect[2][1] = thresh.shape[0]
    rect[1] = [thresh.shape[1], 0]
    w = LA.norm(rect[1] - rect[0])
    rect[0] = rect[1] + [-w, 0]
    rect[3] = rect[2] + [-w, 0]
    # 透視変換
    cropped = four_point_transform(thresh, rect)
    return cropped

# 切り取ったroiから数字を認識する
def digits_recognizer(roi, mode = 0):
    digit = None
    roi = imutils.resize(roi, height=64)
    # 透視変換
    if mode == 1:
        roi = perspective_tf(roi)
    (h, w) = roi.shape
    d = int(round(w / 4))
    d2 = int(round(d / 2))
    d3 = int(round(d / 3))
    d4 = int(round(d / 4))
    hc = int(round(h / 2))
    segments = [
        ((d, d3), (w - d, d - d3)),  # top
        ((d3, d), (d - d3, hc - d2)),  # top-left
        ((w - d + d3, d), (w - d3, hc - d2)),  # top-right
        ((d, hc - d4), (w - d, hc + d4)),  # center
        ((d3, hc + d2), (d - d3, h - d)),  # bottom-left
        ((w - d + d3, hc + d2), (w - d3, h - d)),  # bottom-right
        ((d, h - d + d3), (w - d, h - d3))  # bottom
    ]
    on = [0] * len(segments)
    for (k, ((xA, yA), (xB, yB))) in enumerate(segments):
        segROI = roi[yA:yB, xA:xB]
        total = cv2.countNonZero(segROI)
        area = (xB - xA) * (yB - yA)
        try:
            if total / float(area) > 0.5:
                on[k] = 1
            digit = DIGITS_LOOKUP[tuple(on)]
        except ZeroDivisionError:
            continue
        except:
            digit = 'X'
    if digit == None:
        return 'X'
    else:
        return digit

DIGITS_LOOKUP = {
    (1, 1, 1, 0, 1, 1, 1): 0,
    (1, 0, 1, 1, 1, 0, 1): 2,
    (1, 0, 1, 1, 0, 1, 1): 3,
    (0, 1, 1, 1, 0, 1, 0): 4,
    (1, 1, 0, 1, 0, 1, 1): 5,
    (1, 1, 0, 1, 1, 1, 1): 6,
    (1, 0, 1, 0, 0, 1, 0): 7,
    (1, 1, 1, 0, 0, 1, 0): 7,
    (1, 1, 1, 1, 1, 1, 1): 8,
    (1, 1, 1, 1, 0, 1, 1): 9
}

def recog_main(im, invert):
    # image resize
    if im.shape[0] < 200:
        im = imutils.resize(im, height=200)

    # 認識結果の格納用
    R_digits = []

    # グレーに変換
    if im.shape[2] == 3:
        im_gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
    else:
        im_gray = im

    # ノイズ除去
    im_gray = cv2.bilateralFilter(im_gray,12,75,75) # noise removal while keeping edges sharp

    # 色反転
    invert = int(invert)
    if invert:
        thresh_inv = True
    else:
        thresh_inv = False

    # 二値化
    if thresh_inv:
        thresh = cv2.threshold(255 - im_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
    else:
        thresh = cv2.threshold(im_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]

    # morph openingによるノイズ除去
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    thresh_open = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)

    # morph closingによる1や0など中間部分が繋がってないのを繋ぐ
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (1, 15))
    thresh_close = cv2.morphologyEx(thresh_open, cv2.MORPH_CLOSE, kernel)

    # close AND open^
    thresh_tmp = cv2.bitwise_and(thresh_close, cv2.bitwise_not(thresh_open))

    # 中間部分以外に繋がった部分を0にする
    thresh_height = thresh_tmp.shape[0]
    zero_idx = tuple(list(range(0, thresh_height // 4 + 5)) + list(range(thresh_height - thresh_height // 4, thresh_height)))
    thresh_tmp[zero_idx, :] = np.zeros((1, thresh_tmp.shape[1]))

    # morph opening OR 中間部分を繋ぐ要素
    thresh = cv2.bitwise_or(thresh_open, thresh_tmp)

    # 左右で繋がってない部分を繋ぐ
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (10, 1))
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)

    # 上下で繋がってない部分を繋ぐ
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 10))
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)

    # 輪郭を抽出
    cnts = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[1]

    # 各輪郭を囲む最小の四角形の高さを求め、その中で一番大きい値を求める
    h_list = []
    for cc in cnts:
        (x, y, w, h) = cv2.boundingRect(cc)
        h_list.append(h)
    h_max = max(h_list)

    # 最大の縦の長さの0.77倍以上の縦の長さを持つ輪郭を対象とする
    digitCnts = []
    for cc in cnts:
        (x, y, w, h) = cv2.boundingRect(cc)
        if h >= h_max * 0.77:
            digitCnts.append(cc)

    # 輪郭を左から右の順に並べる
    digitCnts = contours.sort_contours(digitCnts, method="left-to-right")[0]

    # 識別段階
    for c in digitCnts:
        (x, y, w, h) = cv2.boundingRect(c)
        # 幅が縦より長いと対象外
        if w > h:
            continue
        # 幅が縦の1/2.7より小さいと1とする
        elif w < h / 2.7:
            digit = 1
        else:
            roi = thresh[y:y + h, x:x + w]
            # 識別器
            digit = digits_recognizer(roi)
            # 識別できなかったら幅を縦の長さの1/2にしてもう一度識別
            # (小数点が数字の右下に付いている場合の対処法)
            if digit == 'X':
                w = int(round(h / 2))
                roi = thresh[y:y + h, x:x + w]
                digit = digits_recognizer(roi)
            # 透視変換適用
            if digit == 'X':
                digit = digits_recognizer(roi, 1)
        # 幅の再設定や透視変換適用でもできない場合は失敗として'X'を入れる
        R_digits.append(digit)

    # 認識結果の文字列
    output_str = u''.join(str(e) for e in R_digits)
    return output_str